#include "direction.hpp"
#include <cstdlib>

// Gradient direction quantized to 4 sectors: 0, 45, 90, 135 degrees.
//
// Uses integer cross-multiplication instead of atan2() to avoid floating point.
// The angle boundaries are at 22.5°, 67.5°, 112.5°, and 157.5°.
//
// Key tangent approximations (cross-multiplied to eliminate division):
//   tan(22.5°) ≈ 0.4142  → ay * 5 < ax * 2   (below 22.5°)
//   tan(67.5°) ≈ 2.4142  → ay * 5 < ax * 12  (below 67.5°)
//
// Working with ax = |gx|, ay = |gy| maps all angles into [0°, 90°].
// The sign of gx*gy then distinguishes 45° (same sign) from 135° (opposite sign).
Image gradientDirection(const Gradient& grad)
{
    Image output(grad.width, grad.height);

    for(int y = 0; y < grad.height; y++)
    {
        for(int x = 0; x < grad.width; x++)
        {
            int index = y * grad.width + x;
            int gx = grad.gx[index];
            int gy = grad.gy[index];
            int ax = std::abs(gx);
            int ay = std::abs(gy);

            uint8_t quantized;

            if(ay * 5 < ax * 2)
            {
                // Angle below 22.5° or above 157.5° → horizontal gradient
                quantized = 0;
            }
            else if(ay * 5 < ax * 12)
            {
                // Angle in [22.5°, 67.5°) or (112.5°, 157.5°]
                // Sign of gx*gy distinguishes the two diagonal sectors:
                //   same sign  (gx*gy >= 0) → 45°
                //   diff sign  (gx*gy <  0) → 135°
                quantized = (gx * gy >= 0) ? 45 : 135;
            }
            else
            {
                // Angle in [67.5°, 112.5°] → vertical gradient
                quantized = 90;
            }

            output.at(x, y) = quantized;
        }
    }

    return output;
}