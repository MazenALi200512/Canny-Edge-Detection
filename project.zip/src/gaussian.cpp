#include "gaussian.hpp"
#include "convolution.hpp"

// 5x5 Gaussian kernel with sigma ~1.0, integer coefficients summing to 273.
// Stored flat (row-major) for use with the generic convolve2D template.
static const int16_t GAUSS_KERNEL[25] =
{
    1,  4,  7,  4,  1,
    4, 16, 26, 16,  4,
    7, 26, 41, 26,  7,
    4, 16, 26, 16,  4,
    1,  4,  7,  4,  1
};

static constexpr int32_t KERNEL_SUM = 273;

// gaussianBlur delegates to the generic convolve2D template.
//   PixelType  = uint8_t  (grayscale pixels, 0-255)
//   AccumType  = int32_t  (max intermediate value: 255*41*25 ≈ 261k, fits i32)
//   KernelType = int16_t  (coefficients 1-41, fit in i16)
// Zero-padding boundary: OOB pixels contribute 0; divisor stays 273.
Image gaussianBlur(const Image& input)
{
    return convolve2D<uint8_t, int32_t, int16_t>(
        input, GAUSS_KERNEL, 5, 5, KERNEL_SUM);
}