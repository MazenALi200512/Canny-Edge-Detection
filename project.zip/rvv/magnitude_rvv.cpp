#include <riscv_vector.h>
#include "magnitude.hpp"

// RVV L1 magnitude: output[i] = clamp(|gx[i]| + |gy[i]|, 0, 255)
//
// LMUL chain (e16m4 base):
//   vsetvl_e16m4          set vl for 16-bit elements, LMUL=4
//                         → vl=32 at vlen=128, 64 at vlen=256, 128 at vlen=512
//   vle16     i16m4       load gx / gy (32 elements per load at vlen=128)
//   vneg      i16m4       negate (for abs trick)
//   vmax      i16m4       abs = max(x, -x)
//   vadd      i16m4       mag = |gx| + |gy|
//   vmin      i16m4       clamp to 255
//   vreinterpret u16m4    reinterpret signed as unsigned for narrowing
//   vnclipu   u8m2        narrow u16m4 -> u8m2 (LMUL halved: m4/2 = m2)
//   vse8      u8m2        store vl bytes directly to output
//
// Why e16m4 (not e16m1):
//   At vlen=128, e16m1 gives only 8 pixels per iteration (125,000 iterations
//   for a 1000x1000 image). QEMU has significant per-instruction overhead, so
//   each vsetvl + loop-overhead cost is paid 125,000 times.
//   e16m4 gives 32 pixels per iteration (31,250 iterations) — 4x fewer
//   loop iterations, 4x less overhead. The instruction count per pixel stays
//   the same; only the amortized per-iteration cost drops.
//   On real hardware e16m4 also fills more of the vector datapath per cycle.
//
// Why vnclipu (not vnsrl):
//   vnclipu saturates out-of-range values, giving a safe clamp to [0,255]
//   on the narrowing step. Since vmin already clamped to 255 above, this
//   saturation never fires — but it protects against overflow if the clamp
//   is ever removed or the inputs change.
//
// VLA behaviour:
//   vsetvl_e16m4 returns however many elements the hardware supports at
//   LMUL=4. The while loop advances by vl each iteration, so the tail
//   (remaining < vl) is handled automatically on the last iteration.
//   The binary produces correct output at vlen=128, 256, and 512 without
//   any code changes.
Image magnitudeL1_rvv(const Gradient& grad)
{
    Image output(grad.width, grad.height);

    int   total = grad.width * grad.height;
    int   i     = 0;

    while(i < total)
    {
        // How many 16-bit elements to process this iteration.
        // vlen=128 → 32,  vlen=256 → 64,  vlen=512 → 128
        size_t vl = __riscv_vsetvl_e16m4(total - i);

        // Load gx and gy as signed 16-bit vectors (SoA layout: contiguous)
        vint16m4_t gx = __riscv_vle16_v_i16m4(grad.gx.data() + i, vl);
        vint16m4_t gy = __riscv_vle16_v_i16m4(grad.gy.data() + i, vl);

        // Absolute value: abs(x) = max(x, -x)
        // RVV 1.0 has no integer vabs; this two-instruction idiom is standard.
        gx = __riscv_vmax_vv_i16m4(gx, __riscv_vneg_v_i16m4(gx, vl), vl);
        gy = __riscv_vmax_vv_i16m4(gy, __riscv_vneg_v_i16m4(gy, vl), vl);

        // L1 magnitude: |gx| + |gy|
        // Max value: 255 + 255 = 510, fits in int16_t (max 32,767) — no overflow
        vint16m4_t mag = __riscv_vadd_vv_i16m4(gx, gy, vl);

        // Clamp to 255 (scalar broadcast then element-wise min)
        mag = __riscv_vmin_vv_i16m4(mag,
                  __riscv_vmv_v_x_i16m4(255, vl), vl);

        // Narrow i16m4 -> u8m2 and store directly to output (no temp buffer).
        // vreinterpret is a compile-time type rename — zero runtime cost.
        // vnclipu shift=0 keeps the lower 8 bits; RDN rounding mode.
        vuint16m4_t mag_u  = __riscv_vreinterpret_v_i16m4_u16m4(mag);
        vuint8m2_t  mag_u8 = __riscv_vnclipu_wx_u8m2(
                                 mag_u, 0, __RISCV_VXRM_RDN, vl);

        // Store vl bytes directly into the output image — no scalar loop needed
        __riscv_vse8_v_u8m2(output.data.data() + i, mag_u8, vl);

        i += (int)vl;
    }

    return output;
}