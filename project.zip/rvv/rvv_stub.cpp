// Host-side stubs for RVV functions.
// On the host (x86/ARM), these simply delegate to the scalar implementations
// so that main.cpp links and the mismatch checks still run meaningfully.
// The real RVV implementations in this directory are compiled only for RISC-V.

#include "gaussian.hpp"
#include "magnitude.hpp"

Image gaussianBlur_rvv(const Image& input)
{
    return gaussianBlur(input);
}

Image magnitudeL1_rvv(const Gradient& grad)
{
    return magnitudeL1(grad);
}